rm -rf classes
mkdir classes
javac -d classes *.java
cd classes

# input_parameters$1.prp中的 numberOfProcesses为30
# 这里改变seed 与 meanCpuBurst
for i in {1..4}
do
  for j in {1..4}
  do
    java InputGenerator ../../../../experiment1/seed$i/input_parameters$j.prp ../../../../experiment1/seed$i/input$j.in
  done
done

#Experiment 1 Simulation for First Come First Served implementation
for i in {1..4}
do
  for j in {1..4}
  do
    java Simulator ../../../../experiment1/seed$i/simulator_parameters_FCFS.prp ../../../../experiment1/seed$i/output$$j_FCFS.out ../../../../experiment1/seed$i/input$j.in
    java Simulator ../../../../experiment1/seed$i/simulator_parameters_Feedback.prp ../../../../experiment1/seed$i/output$j_Feedback.out ../../../../experiment1/seed$i/input$j.in
    java Simulator ../../../../experiment1/seed$i/simulator_parameters_IdealSJFS.prp ../../../../experiment1/seed$i/output$j_IdealSJFS.out ../../../../experiment1/seed$i/input$j.in
    java Simulator ../../../../experiment1/seed$i/simulator_parameters_RRS.prp ../../../../experiment1/seed$i/output$j_RRS.out ../../../../experiment1/seed$i/input$j.in
    java Simulator ../../../../experiment1/seed$i/simulator_parameters_SJFS.prp ../../../../experiment1/seed$i/output$j_SJFS.out ../../../../experiment1/seed$i/input$j.in
  done
done 
